Each middleware program sends one message to the network. 
The network program braodcasts each received message to all the middleware programs after a random delay.


1. Run the program using batch file run.bat in a Visual Studio developer command prompt.
2. To make the Middleware send messages to the Network, press the "return" key ONCE in each of the command windows for the Middleware.
